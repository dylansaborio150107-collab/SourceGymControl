# SourceGymControl

Sistema web de gestión y administración de gimnasios: clientes, membresías, control de accesos, pagos, rutinas, progreso físico, alertas, reportes y ajustes.

Aplicación **100% estática** (HTML + Tailwind + JavaScript vanilla) lista para publicar en Netlify, Vercel o cualquier hosting de archivos. No requiere servidor ni base de datos: los datos se guardan en el `localStorage` del navegador y pueden exportarse/importarse como respaldo JSON.

---

## 1. Puesta en marcha

### Local

```bash
# cualquier servidor estático sirve
npx serve .
# luego abre http://localhost:3000/app/index.html
```

Abrir el archivo con `file://` también funciona, pero se recomienda un servidor para que las rutas de assets se resuelvan igual que en producción.

### Netlify

1. Sube el proyecto (o conéctalo al repositorio).
2. **Publish directory:** `public`
3. **Build command:** vacío (no hay build).
4. La aplicación queda disponible en `/app/index.html`; la raíz `/` redirige automáticamente al panel.

---

## 2. Acceso al sistema

El sistema arranca con un usuario administrador precargado. Las credenciales **no se muestran en la pantalla de inicio de sesión** por seguridad; se entregan al responsable del gimnasio y se cambian en **Ajustes → Mi cuenta** en el primer ingreso.

| Rol | Alcance |
| --- | --- |
| Administrador | Acceso total: usuarios, roles, base de datos, historial y todos los módulos. |
| Recepcionista | Clientes, membresías, control de accesos, pagos y reportes. |
| Entrenador | Clientes, rutinas, ejercicios, progreso físico y reportes. |
| Cliente | Solo su rutina asignada (**Mi rutina**). |

Recomendaciones:

- Cambia la contraseña del administrador en **Ajustes → Mi cuenta**.
- Crea un usuario por persona en **Usuarios y roles** en lugar de compartir cuentas.
- Exporta un respaldo desde **Ajustes → Datos y mantenimiento** periódicamente.

---

## 3. Arquitectura

### 3.1 Visión general

```text
Navegador
  ├── index.html ............ shell: login + contenedor de la app
  ├── theme.js .............. tema claro/oscuro y preferencias de interfaz
  ├── schema.js ............. definición de tablas, columnas, PK/FK y permisos
  ├── db.js ................. "motor" de datos sobre localStorage + reglas de negocio
  ├── ui.js ................. helpers de interfaz (tablas, modales, toasts, iconos, gráficos)
  ├── views.js .............. vistas de cada módulo
  ├── settings.js ........... vista de Ajustes (apariencia, cuenta, gimnasio, respaldos)
  └── app.js ................ sesión, permisos, layout responsive y router por hash
```

Flujo de una pantalla:

```text
hash (#/clientes)
   → app.js: router → verifica sesión y permiso
   → views.js: renderiza la vista en <main id="view">
   → db.js: lee/escribe datos y emite eventos
   → ui.js: pinta tablas, formularios y notificaciones
```

### 3.2 Estructura de carpetas

```text
.
├── README.md
├── public/
│   ├── favicon.png                 icono del sitio (derivado del logo)
│   ├── robots.txt
│   └── app/
│       ├── index.html              login + shell de la aplicación
│       ├── assets/
│       │   ├── logo.jpg            logo original (color)
│       │   ├── logo-white.png      logo en blanco para el panel oscuro del login
│       │   └── gym-bg.jpg          fondo del panel de marca
│       ├── css/
│       │   └── styles.css          sistema de diseño (tokens, componentes, temas)
│       └── js/
│           ├── schema.js
│           ├── db.js
│           ├── theme.js
│           ├── ui.js
│           ├── views.js
│           ├── settings.js
│           └── app.js
└── src/                            capa de hosting (redirección de / al panel)
```

### 3.3 Capa de datos

- `schema.js` declara las tablas (`Clientes`, `Membresias`, `Pagos`, `Accesos`, `Rutinas`, `RutinaDetalle`, `Ejercicios`, `Entrenadores`, `Progreso`, `Alertas`, `Usuarios`, `Roles`, `Auditoria`, …), sus columnas y los permisos de cada rol.
- `db.js` expone una API tipo ORM: `all`, `find`, `where`, `insert`, `update`, `remove`, además de lógica de negocio (`membresiaActual`, `diasRestantes`, `registrarEntrada`, `registrarSalida`, `refreshAlertas`).
- Toda escritura se audita en la tabla `Auditoria` (visible en **Historial**) y se persiste en `localStorage` bajo la clave `sgc_db_v1`.
- **Respaldo/restauración:** `Ajustes → Datos y mantenimiento` exporta un JSON con los datos y la configuración del gimnasio, y permite volver a importarlo o restablecer los datos de ejemplo.

### 3.4 Sesión y permisos

- La sesión se guarda en `sessionStorage` (`sgc_session`) y se restaura al recargar.
- Cada entrada del menú declara el permiso requerido; el router vuelve a comprobarlo antes de renderizar, de modo que escribir un hash a mano no salta la restricción.
- El menú lateral solo muestra los módulos permitidos para el rol activo.

> Al ser una aplicación de cliente, la validación es funcional (no criptográfica). Para un despliegue multiusuario en internet, conviene mover autenticación y datos a un backend.

---

## 4. Arquitectura de diseño

### 4.1 Sistema de temas

`css/styles.css` define una escala neutra y de marca como variables CSS (`--s50…--s950`, `--b300…--b900`). Tailwind está configurado para consumir esas variables, por lo que las clases (`bg-slate-900`, `text-slate-200`, `text-brand-500`, …) se adaptan automáticamente al tema activo.

- Tema **oscuro** = valores por defecto en `:root`.
- Tema **claro** = clase `html.light`, que invierte la escala neutra.
- El tema se aplica antes del primer pintado (script inline en `<head>`) para evitar destellos.
- Se guarda en `localStorage` (`sgc_theme`); si no hay preferencia, se usa la del sistema operativo.
- El panel de marca del login mantiene la paleta oscura de forma fija, porque el logo es blanco.

Se puede alternar el tema desde: el botón de la pantalla de inicio de sesión, el botón del encabezado y **Ajustes → Apariencia**.

### 4.2 Tokens y componentes

| Token | Uso |
| --- | --- |
| `--page`, `--surface`, `--elevated` | fondos de página, tarjetas y elementos elevados |
| `--line`, `--line-strong` | bordes y separadores |
| `--text`, `--text-strong`, `--text-muted` | jerarquía tipográfica |
| `--primary`, `--primary-hover`, `--primary-soft` | acción principal y estados |
| `--shadow-card` | profundidad de tarjetas |

Clases de componente reutilizables: `.card`, `.btn-primary`, `.btn-ghost`, `.btn-danger`, `.icon-btn`, `.inp`, `.lbl`, `.tab`, `.tab-on`, `.switch`, `.badge`, `.nav-item`, `.table-wrap`.

### 4.3 Identidad visual

- **Color de marca:** azul `#3B6EF6` sobre neutros pizarra.
- **Tipografía:** Inter (fallback a la del sistema).
- **Radios:** 0.75–1rem; sombras suaves y difusas.
- **Movimiento:** entradas `fadeUp` discretas, transiciones de 200–300 ms; se pueden desactivar en **Ajustes → Apariencia**.

### 4.4 Comportamiento responsive

- **Móvil (< 1024 px):** menú lateral fuera de pantalla que se abre con el botón de hamburguesa. Se cierra con la X del propio menú, tocando el fondo oscuro, con la tecla `ESC` o al navegar a otra sección. El scroll del cuerpo se bloquea mientras está abierto.
- **Escritorio (≥ 1024 px):** menú fijo, con opción de **contraerlo a solo iconos** (`Contraer menú` al pie del menú o el interruptor de Ajustes). La preferencia se recuerda.
- Encabezados y filas usan rejillas de dos columnas con `min-w-0` y `truncate`, de modo que ningún texto largo rompe el diseño.
- Las tablas se desplazan horizontalmente dentro de su contenedor en pantallas pequeñas.

---

## 5. Módulos

| Sección | Descripción |
| --- | --- |
| Dashboard | Indicadores clave, asistencia de 7 días, ingresos de 6 meses, quién está dentro y alertas recientes. |
| Clientes | Ficha completa: datos personales, medidas, objetivo, nivel, membresía vigente y estado. |
| Membresías | Planes, fechas de inicio/fin, renovaciones y control de vencimientos. |
| Control de accesos | Registro de entradas y salidas por QR, código o manual; detección de asistencias sin salida. |
| Pagos | Cobros, métodos, estado (pagado/pendiente) e ingresos por periodo. |
| Rutinas / Programador / Ejercicios | Creación de planes por objetivo y nivel, con series, repeticiones, carga y descanso. |
| Entrenadores | Personal técnico y clientes asignados. |
| Progreso físico | Evolución de peso, grasa, masa muscular y perímetros. |
| Alertas | Membresías vencidas o por vencer, pagos pendientes y asistencias incompletas. |
| Reportes | Consolidados exportables de clientes, ingresos y asistencia. |
| Usuarios y roles | Gestión de cuentas y permisos (solo administrador). |
| Historial | Auditoría de todas las operaciones. |
| Base de datos | Consulta del esquema y ejecución de consultas simples. |
| Mi rutina | Vista del cliente con su plan de entrenamiento. |
| **Ajustes** | Apariencia (tema, densidad, menú), Mi cuenta (nombre, correo, contraseña), Datos del gimnasio y Respaldos. |

---

## 6. Convenciones de código

- JavaScript vanilla en IIFE, expuesto en `window.SGC_*` (`SGC_DB`, `SGC_UI`, `SGC_THEME`, `SGC_VIEWS`, `SGC_SESSION`, `SGC_GYM`).
- Interfaz y datos en **español**; los identificadores de tabla y columna respetan el esquema original.
- Todo contenido dinámico se escapa con `U.esc()` antes de insertarse en el DOM.
- Los estilos nuevos se agregan como tokens o clases de componente en `css/styles.css`, nunca como colores fijos en el marcado.
- Una vista nueva se añade a `views.js` (o a su propio archivo, como `settings.js`), se registra en `SGC_VIEWS` y se enlaza en el menú y el router de `app.js`.
